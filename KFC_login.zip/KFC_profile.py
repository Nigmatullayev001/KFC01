from tkinter import *
from tkinter.ttk import Combobox
from base import Database

db = Database()

window = Tk()

image_icon = PhotoImage(file="Image(KFC)/logo2.png")
window.iconphoto(True, image_icon)

width = window.winfo_screenwidth()
height = window.winfo_screenheight()
center_x = int(width / 2 - 150 / 2)
center_y = int(height / 2 - 100 / 2)
window.geometry(f"{150}x{100}+{center_x}+{center_y}")
window.title("KFC Uzbekistan")
window.configure(bg="darkred")

entry = Entry(window)
entry.grid(row=0, column=0)


def log_in():
    window.destroy()


def delete_user():
    id_u = entry.get()
    db.delete_user(name=id_u,)
    entry.delete(0, END)

button = Button(window, text="Delete", command=delete_user)
button.grid(row=1, column=0)

window.mainloop()
